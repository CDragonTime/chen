// @ts-nocheck

export { connect, useDispatch, useStore, useSelector } from 'G:/项目文件/react_pro/react_prodemo/node_modules/dva';
export { getApp as getDvaApp } from './dva';
