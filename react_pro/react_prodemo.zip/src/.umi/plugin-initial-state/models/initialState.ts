// @ts-nocheck
export default () => ({ loading: false, refresh: () => {} })